/* Dire Wolf cm108.h */

extern void cm108_find_ptt (char *output_audio_device, char *ptt_device, int ptt_device_size);

extern int cm108_set_gpio_pin (char *name, int num, int state);