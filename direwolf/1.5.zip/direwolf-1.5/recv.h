
/* recv.h */

void recv_init (struct audio_s *pa);

void recv_process (void);