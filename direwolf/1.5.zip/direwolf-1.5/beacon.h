
/* beacon.h */

void beacon_init (struct audio_s *pmodem, struct misc_config_s *pconfig, struct igate_config_s *pigate);

void beacon_tracker_set_debug (int level);
