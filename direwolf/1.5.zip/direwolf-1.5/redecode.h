

#ifndef REDECODE_H
#define REDECODE_H 1

#include "rrbb.h"	


extern void redecode_init (struct audio_s *p_audio_config);


#endif

/* end redecode.h */

