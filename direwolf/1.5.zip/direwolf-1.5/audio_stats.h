

/* audio_stats.h */


extern void audio_stats (int adev, int nchan, int nsamp, int interval);

