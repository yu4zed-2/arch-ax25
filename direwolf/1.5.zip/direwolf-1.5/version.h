
/* Dire Wolf version 1.5 */

#define APP_TOCALL "APDW"

#define MAJOR_VERSION 1
#define MINOR_VERSION 5
//#define EXTRA_VERSION "Beta Test"
