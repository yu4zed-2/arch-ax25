

void utm_error_string (long err, char *str);

void mgrs_error_string (long err, char *str);

void usng_error_string (long err, char *str);
