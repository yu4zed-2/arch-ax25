
/* fcs_calc.h */


unsigned short fcs_calc (unsigned char *data, int len);

unsigned short crc16 (unsigned char *data, int len, unsigned short seed);

/* end fcs_calc.h */


